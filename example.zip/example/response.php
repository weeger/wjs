<?php

// Load wjs.
require_once "library/wjs/wjs.inc";
$w = new wjs('library/wjs');

// Using this simple script is not secure.
// You may filter data to ensure that values
// are safe, according your own security policy.
$script_type = (isset($_GET['t'])) ? $_GET['t'] : FALSE;
$script_name = (isset($_GET['s'])) ? $_GET['s'] : FALSE;

// Register your scripts.
$w->collection_item_register('javascript', 'my_script', 'library/scripts/my_script.js');
// Append requested scripts.
$w->output_append($script_type, $script_name);

// Render.
print $w->js_package();