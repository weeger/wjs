<?php

// Load wjs.
require_once "library/wjs/wjs.inc";
$w = new wjs('library/wjs');
// Define response path.
$w->js_setting('path_response', 'response.php');

?><!DOCTYPE html>
<html>
<head>
  <title>wJs example</title>
  <script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
  <?php print $w->js_header(); ?>
</head>
<body>
<input type="button" onclick="w.load('javascript','my_script');" value="Click me"/>
<?php print $w->js_footer(); ?>
</body>
</html>